
# Slot: input_id




URI: [composite_disease:extractionResult__input_id](http://w3id.org/ontogpt/composite_disease/extractionResult__input_id)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
