
# Slot: mechanism




URI: [composite_disease:treatmentMechanism__mechanism](http://w3id.org/ontogpt/composite_disease/treatmentMechanism__mechanism)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Mechanism](Mechanism.md)

## Parents


## Children


## Used by

 * [TreatmentMechanism](TreatmentMechanism.md)
