
# Slot: prompt




URI: [composite_disease:extractionResult__prompt](http://w3id.org/ontogpt/composite_disease/extractionResult__prompt)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
