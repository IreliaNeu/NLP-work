
# Enum: NCITTActivityType




URI: [composite_disease:NCITTActivityType](http://w3id.org/ontogpt/composite_disease/NCITTActivityType)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

