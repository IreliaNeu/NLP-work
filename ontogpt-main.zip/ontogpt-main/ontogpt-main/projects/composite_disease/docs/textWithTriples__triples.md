
# Slot: triples




URI: [composite_disease:textWithTriples__triples](http://w3id.org/ontogpt/composite_disease/textWithTriples__triples)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Triple](Triple.md)

## Parents


## Children


## Used by

 * [TextWithTriples](TextWithTriples.md)
