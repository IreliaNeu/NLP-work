
# Slot: subject




URI: [composite_disease:triple__subject](http://w3id.org/ontogpt/composite_disease/triple__subject)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
