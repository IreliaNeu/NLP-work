
# Enum: NCITDrugType




URI: [composite_disease:NCITDrugType](http://w3id.org/ontogpt/composite_disease/NCITDrugType)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

