
# Slot: main_disease


the name of the disease that is treated.

URI: [composite_disease:compositeDisease__main_disease](http://w3id.org/ontogpt/composite_disease/compositeDisease__main_disease)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Disease](Disease.md)

## Parents


## Children


## Used by

 * [CompositeDisease](CompositeDisease.md)
