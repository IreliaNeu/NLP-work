
# Slot: full_text


The full text of the publication

URI: [composite_disease:publication__full_text](http://w3id.org/ontogpt/composite_disease/publication__full_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
