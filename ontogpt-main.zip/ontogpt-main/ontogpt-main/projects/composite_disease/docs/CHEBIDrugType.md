
# Enum: CHEBIDrugType




URI: [composite_disease:CHEBIDrugType](http://w3id.org/ontogpt/composite_disease/CHEBIDrugType)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

