
# Slot: treatment




URI: [composite_disease:treatmentEfficacy__treatment](http://w3id.org/ontogpt/composite_disease/treatmentEfficacy__treatment)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Treatment](Treatment.md)

## Parents


## Children


## Used by

 * [TreatmentEfficacy](TreatmentEfficacy.md)
