
# Slot: efficacy




URI: [composite_disease:treatmentEfficacy__efficacy](http://w3id.org/ontogpt/composite_disease/treatmentEfficacy__efficacy)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [TreatmentEfficacy](TreatmentEfficacy.md)
