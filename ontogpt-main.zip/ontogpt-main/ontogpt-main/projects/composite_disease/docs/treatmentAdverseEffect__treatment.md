
# Slot: treatment




URI: [composite_disease:treatmentAdverseEffect__treatment](http://w3id.org/ontogpt/composite_disease/treatmentAdverseEffect__treatment)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Treatment](Treatment.md)

## Parents


## Children


## Used by

 * [TreatmentAdverseEffect](TreatmentAdverseEffect.md)
