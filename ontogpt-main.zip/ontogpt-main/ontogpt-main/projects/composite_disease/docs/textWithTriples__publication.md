
# Slot: publication




URI: [composite_disease:textWithTriples__publication](http://w3id.org/ontogpt/composite_disease/textWithTriples__publication)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Publication](Publication.md)

## Parents


## Children


## Used by

 * [TextWithTriples](TextWithTriples.md)
