
# Slot: id


The publication identifier

URI: [composite_disease:publication__id](http://w3id.org/ontogpt/composite_disease/publication__id)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
