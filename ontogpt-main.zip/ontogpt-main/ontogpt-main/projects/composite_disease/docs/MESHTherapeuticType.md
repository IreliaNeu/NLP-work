
# Enum: MESHTherapeuticType




URI: [composite_disease:MESHTherapeuticType](http://w3id.org/ontogpt/composite_disease/MESHTherapeuticType)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

