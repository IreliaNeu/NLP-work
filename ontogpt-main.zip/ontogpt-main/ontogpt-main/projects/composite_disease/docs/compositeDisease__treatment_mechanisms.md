
# Slot: treatment_mechanisms


semicolon-separated list of treatment to asterisk-separated mechanism associations

URI: [composite_disease:compositeDisease__treatment_mechanisms](http://w3id.org/ontogpt/composite_disease/compositeDisease__treatment_mechanisms)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TreatmentMechanism](TreatmentMechanism.md)

## Parents


## Children


## Used by

 * [CompositeDisease](CompositeDisease.md)
