
# Slot: treatment_efficacies


semicolon-separated list of treatment to efficacy associations, e.g. Imatinib*effective

URI: [composite_disease:compositeDisease__treatment_efficacies](http://w3id.org/ontogpt/composite_disease/compositeDisease__treatment_efficacies)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TreatmentEfficacy](TreatmentEfficacy.md)

## Parents


## Children


## Used by

 * [CompositeDisease](CompositeDisease.md)
