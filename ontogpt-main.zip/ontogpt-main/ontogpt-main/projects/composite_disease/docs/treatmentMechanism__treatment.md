
# Slot: treatment




URI: [composite_disease:treatmentMechanism__treatment](http://w3id.org/ontogpt/composite_disease/treatmentMechanism__treatment)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Treatment](Treatment.md)

## Parents


## Children


## Used by

 * [TreatmentMechanism](TreatmentMechanism.md)
