
# Slot: title


The title of the publication

URI: [composite_disease:publication__title](http://w3id.org/ontogpt/composite_disease/publication__title)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
