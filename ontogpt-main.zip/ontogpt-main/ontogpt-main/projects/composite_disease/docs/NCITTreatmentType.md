
# Enum: NCITTreatmentType




URI: [composite_disease:NCITTreatmentType](http://w3id.org/ontogpt/composite_disease/NCITTreatmentType)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

