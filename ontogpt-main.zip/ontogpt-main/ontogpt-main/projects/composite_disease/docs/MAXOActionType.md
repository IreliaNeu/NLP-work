
# Enum: MAXOActionType




URI: [composite_disease:MAXOActionType](http://w3id.org/ontogpt/composite_disease/MAXOActionType)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

