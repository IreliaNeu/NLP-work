
# Slot: treatments


semicolon-separated list of therapies and treatments are indicated for treating the disease.

URI: [composite_disease:compositeDisease__treatments](http://w3id.org/ontogpt/composite_disease/compositeDisease__treatments)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Treatment](Treatment.md)

## Parents


## Children


## Used by

 * [CompositeDisease](CompositeDisease.md)
