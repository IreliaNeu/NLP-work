
# Slot: adverse_effects




URI: [composite_disease:treatmentAdverseEffect__adverse_effects](http://w3id.org/ontogpt/composite_disease/treatmentAdverseEffect__adverse_effects)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [AdverseEffect](AdverseEffect.md)

## Parents


## Children


## Used by

 * [TreatmentAdverseEffect](TreatmentAdverseEffect.md)
