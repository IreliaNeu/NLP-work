
# Slot: object_id




URI: [composite_disease:annotatorResult__object_id](http://w3id.org/ontogpt/composite_disease/annotatorResult__object_id)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [AnnotatorResult](AnnotatorResult.md)
