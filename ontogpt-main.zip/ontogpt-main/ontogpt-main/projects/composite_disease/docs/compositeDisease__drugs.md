
# Slot: drugs


semicolon-separated list of named small molecule drugs

URI: [composite_disease:compositeDisease__drugs](http://w3id.org/ontogpt/composite_disease/compositeDisease__drugs)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Drug](Drug.md)

## Parents


## Children


## Used by

 * [CompositeDisease](CompositeDisease.md)
