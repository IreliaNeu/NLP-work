
# Slot: object




URI: [bp:triple__object](http://w3id.org/ontogpt/biotic-interaction-templatetriple__object)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
