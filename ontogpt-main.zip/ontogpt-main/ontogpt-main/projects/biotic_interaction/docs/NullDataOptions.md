
# Enum: NullDataOptions




URI: [bp:NullDataOptions](http://w3id.org/ontogpt/biotic-interaction-templateNullDataOptions)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
| UNSPECIFIED_METHOD_OF_ADMINISTRATION |  | NCIT:C149701 |  |
| NOT_APPLICABLE |  | NCIT:C18902 | {'aliases': ['not applicable', 'N/A']} |
| NOT_MENTIONED |  |  |  |

