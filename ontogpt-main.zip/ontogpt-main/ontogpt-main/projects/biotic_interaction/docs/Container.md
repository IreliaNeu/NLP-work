
# Class: Container




URI: [bp:Container](http://w3id.org/ontogpt/biotic-interaction-templateContainer)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[BioticInteraction]<interactions%200..*-++[Container],[BioticInteraction])](https://yuml.me/diagram/nofunky;dir:TB/class/[BioticInteraction]<interactions%200..*-++[Container],[BioticInteraction])

## Attributes


### Own

 * [➞interactions](container__interactions.md)  <sub>0..\*</sub>
     * Range: [BioticInteraction](BioticInteraction.md)
