
# Slot: input_text




URI: [bp:extractionResult__input_text](http://w3id.org/ontogpt/biotic-interaction-templateextractionResult__input_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
