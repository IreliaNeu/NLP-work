
# Slot: interactions




URI: [bp:container__interactions](http://w3id.org/ontogpt/biotic-interaction-templatecontainer__interactions)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [BioticInteraction](BioticInteraction.md)

## Parents


## Children


## Used by

 * [Container](Container.md)
