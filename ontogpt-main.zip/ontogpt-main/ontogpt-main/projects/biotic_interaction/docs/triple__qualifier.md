
# Slot: qualifier


A qualifier for the statements, e.g. "NOT" for negation

URI: [bp:triple__qualifier](http://w3id.org/ontogpt/biotic-interaction-templatetriple__qualifier)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
