
# Slot: publication




URI: [bp:textWithTriples__publication](http://w3id.org/ontogpt/biotic-interaction-templatetextWithTriples__publication)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Publication](Publication.md)

## Parents


## Children


## Used by

 * [TextWithTriples](TextWithTriples.md)
