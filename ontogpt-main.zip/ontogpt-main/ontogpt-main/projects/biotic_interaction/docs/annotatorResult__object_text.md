
# Slot: object_text




URI: [bp:annotatorResult__object_text](http://w3id.org/ontogpt/biotic-interaction-templateannotatorResult__object_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [AnnotatorResult](AnnotatorResult.md)
