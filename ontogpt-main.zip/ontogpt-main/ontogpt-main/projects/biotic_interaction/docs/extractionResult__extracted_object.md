
# Slot: extracted_object


The complex objects extracted from the text

URI: [bp:extractionResult__extracted_object](http://w3id.org/ontogpt/biotic-interaction-templateextractionResult__extracted_object)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Any](Any.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
