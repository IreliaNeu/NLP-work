
# Slot: target_taxon


the taxon that is the object of the ineteraction

URI: [bp:bioticInteraction__target_taxon](http://w3id.org/ontogpt/biotic-interaction-templatebioticInteraction__target_taxon)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Taxon](Taxon.md)

## Parents


## Children


## Used by

 * [BioticInteraction](BioticInteraction.md)
