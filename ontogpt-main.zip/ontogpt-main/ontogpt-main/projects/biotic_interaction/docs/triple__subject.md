
# Slot: subject




URI: [bp:triple__subject](http://w3id.org/ontogpt/biotic-interaction-templatetriple__subject)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
