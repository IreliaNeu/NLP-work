
# Slot: interaction_type


the type of interaction

URI: [bp:bioticInteraction__interaction_type](http://w3id.org/ontogpt/biotic-interaction-templatebioticInteraction__interaction_type)


## Domain and Range

None &#8594;  <sub>0..1</sub> [InteractionType](InteractionType.md)

## Parents


## Children


## Used by

 * [BioticInteraction](BioticInteraction.md)
