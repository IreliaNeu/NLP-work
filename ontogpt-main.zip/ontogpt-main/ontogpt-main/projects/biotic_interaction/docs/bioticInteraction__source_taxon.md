
# Slot: source_taxon


the taxon that is the subject of the interaction

URI: [bp:bioticInteraction__source_taxon](http://w3id.org/ontogpt/biotic-interaction-templatebioticInteraction__source_taxon)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Taxon](Taxon.md)

## Parents


## Children


## Used by

 * [BioticInteraction](BioticInteraction.md)
