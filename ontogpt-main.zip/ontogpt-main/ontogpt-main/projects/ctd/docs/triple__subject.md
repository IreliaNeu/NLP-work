
# Slot: subject




URI: [drug:triple__subject](http://w3id.org/ontogpt/drug/triple__subject)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children

 *  [ChemicalToDiseaseRelationship➞subject](ChemicalToDiseaseRelationship_subject.md)

## Used by

 * [Triple](Triple.md)
