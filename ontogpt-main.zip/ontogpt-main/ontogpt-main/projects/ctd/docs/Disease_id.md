
# Slot: id




URI: [drug:Disease_id](http://w3id.org/ontogpt/drug/Disease_id)


## Domain and Range

[Disease](Disease.md) &#8594;  <sub>1..1</sub> [String](types/String.md)

## Parents

 *  is_a: [➞id](namedEntity__id.md)

## Children


## Used by

 * [Disease](Disease.md)
