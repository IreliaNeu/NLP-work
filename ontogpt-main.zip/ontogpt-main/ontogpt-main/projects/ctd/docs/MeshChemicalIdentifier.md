
# Enum: MeshChemicalIdentifier




URI: [drug:MeshChemicalIdentifier](http://w3id.org/ontogpt/drug/MeshChemicalIdentifier)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

