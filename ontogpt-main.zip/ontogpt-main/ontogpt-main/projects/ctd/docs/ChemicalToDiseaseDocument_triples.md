
# Slot: triples




URI: [drug:ChemicalToDiseaseDocument_triples](http://w3id.org/ontogpt/drug/ChemicalToDiseaseDocument_triples)


## Domain and Range

[ChemicalToDiseaseDocument](ChemicalToDiseaseDocument.md) &#8594;  <sub>0..\*</sub> [ChemicalToDiseaseRelationship](ChemicalToDiseaseRelationship.md)

## Parents

 *  is_a: [➞triples](textWithTriples__triples.md)

## Children


## Used by

 * [ChemicalToDiseaseDocument](ChemicalToDiseaseDocument.md)
