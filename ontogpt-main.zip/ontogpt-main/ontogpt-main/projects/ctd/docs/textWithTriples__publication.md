
# Slot: publication




URI: [drug:textWithTriples__publication](http://w3id.org/ontogpt/drug/textWithTriples__publication)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Publication](Publication.md)

## Parents


## Children


## Used by

 * [ChemicalToDiseaseDocument](ChemicalToDiseaseDocument.md)
 * [TextWithTriples](TextWithTriples.md)
