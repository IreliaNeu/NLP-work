
# Slot: input_title




URI: [drug:extractionResult__input_title](http://w3id.org/ontogpt/drug/extractionResult__input_title)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
