
# Slot: id




URI: [drug:Chemical_id](http://w3id.org/ontogpt/drug/Chemical_id)


## Domain and Range

[Chemical](Chemical.md) &#8594;  <sub>1..1</sub> [String](types/String.md)

## Parents

 *  is_a: [➞id](namedEntity__id.md)

## Children


## Used by

 * [Chemical](Chemical.md)
