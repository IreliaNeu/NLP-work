
# Slot: qualifier


A qualifier for the statements, e.g. "NOT" for negation

URI: [drug:triple__qualifier](http://w3id.org/ontogpt/drug/triple__qualifier)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ChemicalToDiseaseRelationship](ChemicalToDiseaseRelationship.md)
 * [Triple](Triple.md)
