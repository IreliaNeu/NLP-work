
# Slot: predicate




URI: [drug:triple__predicate](http://w3id.org/ontogpt/drug/triple__predicate)


## Domain and Range

None &#8594;  <sub>0..1</sub> [RelationshipType](RelationshipType.md)

## Parents


## Children

 *  [ChemicalToDiseaseRelationship➞predicate](ChemicalToDiseaseRelationship_predicate.md)

## Used by

 * [Triple](Triple.md)
