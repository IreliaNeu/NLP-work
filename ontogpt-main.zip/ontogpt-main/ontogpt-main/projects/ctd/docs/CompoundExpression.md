
# Class: CompoundExpression




URI: [drug:CompoundExpression](http://w3id.org/ontogpt/drug/CompoundExpression)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[Triple],[CompoundExpression]^-[Triple])](https://yuml.me/diagram/nofunky;dir:TB/class/[Triple],[CompoundExpression]^-[Triple])

## Children

 * [Triple](Triple.md) - Abstract parent for Relation Extraction tasks

## Referenced by Class


## Attributes

