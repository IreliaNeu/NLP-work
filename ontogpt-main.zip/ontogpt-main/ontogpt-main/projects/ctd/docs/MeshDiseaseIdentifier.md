
# Enum: MeshDiseaseIdentifier




URI: [drug:MeshDiseaseIdentifier](http://w3id.org/ontogpt/drug/MeshDiseaseIdentifier)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

