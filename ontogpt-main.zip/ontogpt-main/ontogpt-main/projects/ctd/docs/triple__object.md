
# Slot: object




URI: [drug:triple__object](http://w3id.org/ontogpt/drug/triple__object)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children

 *  [ChemicalToDiseaseRelationship➞object](ChemicalToDiseaseRelationship_object.md)

## Used by

 * [Triple](Triple.md)
