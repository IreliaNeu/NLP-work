
# Slot: triples




URI: [drug:textWithTriples__triples](http://w3id.org/ontogpt/drug/textWithTriples__triples)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Triple](Triple.md)

## Parents


## Children

 *  [ChemicalToDiseaseDocument➞triples](ChemicalToDiseaseDocument_triples.md)

## Used by

 * [TextWithTriples](TextWithTriples.md)
