
# Slot: object


Any measurable clinical attribute.

URI: [diag:DiagnosticProceduretoAttributeAssociation_object](http://w3id.org/ontogpt/diagnostic_procedure/DiagnosticProceduretoAttributeAssociation_object)


## Domain and Range

[DiagnosticProceduretoAttributeAssociation](DiagnosticProceduretoAttributeAssociation.md) &#8594;  <sub>0..\*</sub> [ClinicalAttribute](ClinicalAttribute.md)

## Parents

 *  is_a: [➞object](triple__object.md)

## Children


## Used by

 * [DiagnosticProceduretoAttributeAssociation](DiagnosticProceduretoAttributeAssociation.md)
