
# Slot: triples




URI: [diag:textWithTriples__triples](http://w3id.org/ontogpt/diagnostic_procedure/textWithTriples__triples)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Triple](Triple.md)

## Parents


## Children


## Used by

 * [TextWithTriples](TextWithTriples.md)
