
# Slot: combined_text




URI: [diag:publication__combined_text](http://w3id.org/ontogpt/diagnostic_procedure/publication__combined_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
