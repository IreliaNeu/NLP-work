
# Slot: id


The publication identifier

URI: [diag:publication__id](http://w3id.org/ontogpt/diagnostic_procedure/publication__id)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
