
# Slot: full_text


The full text of the publication

URI: [diag:publication__full_text](http://w3id.org/ontogpt/diagnostic_procedure/publication__full_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
