
# Slot: object




URI: [diag:triple__object](http://w3id.org/ontogpt/diagnostic_procedure/triple__object)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children

 *  [DiagnosticProceduretoAttributeAssociation➞object](DiagnosticProceduretoAttributeAssociation_object.md)
 *  [DiagnosticProceduretoPhenotypeAssociation➞object](DiagnosticProceduretoPhenotypeAssociation_object.md)

## Used by

 * [Triple](Triple.md)
