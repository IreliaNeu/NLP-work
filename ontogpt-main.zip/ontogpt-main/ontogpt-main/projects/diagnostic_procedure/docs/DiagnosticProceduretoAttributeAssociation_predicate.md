
# Slot: predicate


The relationship type, e.g. RELATED_TO

URI: [diag:DiagnosticProceduretoAttributeAssociation_predicate](http://w3id.org/ontogpt/diagnostic_procedure/DiagnosticProceduretoAttributeAssociation_predicate)


## Domain and Range

[DiagnosticProceduretoAttributeAssociation](DiagnosticProceduretoAttributeAssociation.md) &#8594;  <sub>0..1</sub> [ProcedureToAttributePredicate](ProcedureToAttributePredicate.md)

## Parents

 *  is_a: [➞predicate](triple__predicate.md)

## Children


## Used by

 * [DiagnosticProceduretoAttributeAssociation](DiagnosticProceduretoAttributeAssociation.md)
