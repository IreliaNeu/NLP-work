
# Slot: predicate




URI: [diag:triple__predicate](http://w3id.org/ontogpt/diagnostic_procedure/triple__predicate)


## Domain and Range

None &#8594;  <sub>0..1</sub> [RelationshipType](RelationshipType.md)

## Parents


## Children

 *  [DiagnosticProceduretoAttributeAssociation➞predicate](DiagnosticProceduretoAttributeAssociation_predicate.md)
 *  [DiagnosticProceduretoPhenotypeAssociation➞predicate](DiagnosticProceduretoPhenotypeAssociation_predicate.md)

## Used by

 * [Triple](Triple.md)
