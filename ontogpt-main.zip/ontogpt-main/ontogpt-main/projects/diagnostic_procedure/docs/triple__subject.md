
# Slot: subject




URI: [diag:triple__subject](http://w3id.org/ontogpt/diagnostic_procedure/triple__subject)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NamedEntity](NamedEntity.md)

## Parents


## Children

 *  [DiagnosticProceduretoAttributeAssociation➞subject](DiagnosticProceduretoAttributeAssociation_subject.md)
 *  [DiagnosticProceduretoPhenotypeAssociation➞subject](DiagnosticProceduretoPhenotypeAssociation_subject.md)

## Used by

 * [Triple](Triple.md)
