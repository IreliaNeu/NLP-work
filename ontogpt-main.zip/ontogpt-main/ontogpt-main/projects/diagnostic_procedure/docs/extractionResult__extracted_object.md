
# Slot: extracted_object


The complex objects extracted from the text

URI: [diag:extractionResult__extracted_object](http://w3id.org/ontogpt/diagnostic_procedure/extractionResult__extracted_object)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Any](Any.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
