
# Slot: prompt




URI: [diag:extractionResult__prompt](http://w3id.org/ontogpt/diagnostic_procedure/extractionResult__prompt)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
