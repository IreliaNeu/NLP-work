
# Slot: abstract


The abstract of the publication

URI: [diag:publication__abstract](http://w3id.org/ontogpt/diagnostic_procedure/publication__abstract)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
