
# Slot: unit


the unit used to measure the attribute

URI: [diag:clinicalAttribute__unit](http://w3id.org/ontogpt/diagnostic_procedure/clinicalAttribute__unit)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Unit](Unit.md)

## Parents


## Children


## Used by

 * [ClinicalAttribute](ClinicalAttribute.md)
