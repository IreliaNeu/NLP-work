
# Slot: title


The title of the publication

URI: [diag:publication__title](http://w3id.org/ontogpt/diagnostic_procedure/publication__title)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
