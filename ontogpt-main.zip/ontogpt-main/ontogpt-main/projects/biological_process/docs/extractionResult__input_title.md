
# Slot: input_title




URI: [bp:extractionResult__input_title](http://w3id.org/ontogpt/biological-process-templateextractionResult__input_title)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
