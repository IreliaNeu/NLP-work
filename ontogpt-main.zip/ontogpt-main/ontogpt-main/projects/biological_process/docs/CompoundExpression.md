
# Class: CompoundExpression




URI: [bp:CompoundExpression](http://w3id.org/ontogpt/biological-process-templateCompoundExpression)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[Triple],[CompoundExpression]^-[Triple])](https://yuml.me/diagram/nofunky;dir:TB/class/[Triple],[CompoundExpression]^-[Triple])

## Children

 * [Triple](Triple.md) - Abstract parent for Relation Extraction tasks

## Referenced by Class


## Attributes

