
# Slot: steps


the steps involved in this biological process

URI: [bp:biologicalProcess__steps](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__steps)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [MolecularActivity](MolecularActivity.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
