
# Slot: object_id




URI: [bp:annotatorResult__object_id](http://w3id.org/ontogpt/biological-process-templateannotatorResult__object_id)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [AnnotatorResult](AnnotatorResult.md)
