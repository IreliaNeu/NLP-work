
# Slot: abstract


The abstract of the publication

URI: [bp:publication__abstract](http://w3id.org/ontogpt/biological-process-templatepublication__abstract)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
