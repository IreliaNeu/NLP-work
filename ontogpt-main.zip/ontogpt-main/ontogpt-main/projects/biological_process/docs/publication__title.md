
# Slot: title


The title of the publication

URI: [bp:publication__title](http://w3id.org/ontogpt/biological-process-templatepublication__title)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
