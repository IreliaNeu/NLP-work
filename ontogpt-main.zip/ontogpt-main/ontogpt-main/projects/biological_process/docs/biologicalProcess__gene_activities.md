
# Slot: gene_activities


semicolon-separated list of gene to molecular activity relationships

URI: [bp:biologicalProcess__gene_activities](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__gene_activities)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [GeneMolecularActivityRelationship](GeneMolecularActivityRelationship.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
