
# Slot: subclass_of


the category to which this biological process belongs

URI: [bp:biologicalProcess__subclass_of](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__subclass_of)


## Domain and Range

None &#8594;  <sub>0..1</sub> [BiologicalProcess](BiologicalProcess.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
