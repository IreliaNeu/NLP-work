
# Slot: gene




URI: [bp:geneMolecularActivityRelationship__gene](http://w3id.org/ontogpt/biological-process-templategeneMolecularActivityRelationship__gene)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Gene](Gene.md)

## Parents


## Children


## Used by

 * [GeneMolecularActivityRelationship](GeneMolecularActivityRelationship.md)
