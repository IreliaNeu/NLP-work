
# Slot: predicate




URI: [bp:triple__predicate](http://w3id.org/ontogpt/biological-process-templatetriple__predicate)


## Domain and Range

None &#8594;  <sub>0..1</sub> [RelationshipType](RelationshipType.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
