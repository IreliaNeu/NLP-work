
# Slot: molecular_activity




URI: [bp:geneMolecularActivityRelationship__molecular_activity](http://w3id.org/ontogpt/biological-process-templategeneMolecularActivityRelationship__molecular_activity)


## Domain and Range

None &#8594;  <sub>0..1</sub> [MolecularActivity](MolecularActivity.md)

## Parents


## Children


## Used by

 * [GeneMolecularActivityRelationship](GeneMolecularActivityRelationship.md)
