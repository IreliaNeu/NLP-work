
# Type: uriorcurie


a URI or a CURIE

URI: [linkml:Uriorcurie](https://w3id.org/linkml/Uriorcurie)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **URIorCURIE** |
| Representation | | str |
