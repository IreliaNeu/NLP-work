
# Type: date_or_datetime


Either a date or a datetime

URI: [linkml:DateOrDatetime](https://w3id.org/linkml/DateOrDatetime)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **str** |
| Representation | | str |
