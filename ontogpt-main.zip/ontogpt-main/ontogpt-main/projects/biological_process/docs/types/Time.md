
# Type: time


A time object represents a (local) time of day, independent of any particular day

URI: [linkml:Time](https://w3id.org/linkml/Time)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **XSDTime** |
| Representation | | str |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Exact Mappings:** | | schema:Time |

