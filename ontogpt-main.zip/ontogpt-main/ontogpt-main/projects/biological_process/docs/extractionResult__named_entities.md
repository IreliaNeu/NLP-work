
# Slot: named_entities


Named entities extracted from the text

URI: [bp:extractionResult__named_entities](http://w3id.org/ontogpt/biological-process-templateextractionResult__named_entities)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Any](Any.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
