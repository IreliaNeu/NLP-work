
# Class: Any




URI: [bp:Any](http://w3id.org/ontogpt/biological-process-templateAny)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[ExtractionResult]++-%20extracted_object%200..1>[Any],[ExtractionResult]++-%20named_entities%200..*>[Any],[ExtractionResult])](https://yuml.me/diagram/nofunky;dir:TB/class/[ExtractionResult]++-%20extracted_object%200..1>[Any],[ExtractionResult]++-%20named_entities%200..*>[Any],[ExtractionResult])

## Referenced by Class

 *  **None** *[➞extracted_object](extractionResult__extracted_object.md)*  <sub>0..1</sub>  **[Any](Any.md)**
 *  **None** *[➞named_entities](extractionResult__named_entities.md)*  <sub>0..\*</sub>  **[Any](Any.md)**

## Attributes


## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | linkml:Any |

