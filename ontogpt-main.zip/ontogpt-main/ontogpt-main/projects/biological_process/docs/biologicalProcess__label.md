
# Slot: label


the name of the biological process

URI: [bp:biologicalProcess__label](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__label)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
