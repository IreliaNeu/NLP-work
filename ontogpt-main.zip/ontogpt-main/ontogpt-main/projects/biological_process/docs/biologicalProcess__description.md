
# Slot: description


a textual description of the biological process

URI: [bp:biologicalProcess__description](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__description)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
