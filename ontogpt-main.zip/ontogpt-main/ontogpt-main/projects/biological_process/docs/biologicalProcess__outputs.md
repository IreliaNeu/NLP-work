
# Slot: outputs


the outputs of the biological process

URI: [bp:biologicalProcess__outputs](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__outputs)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ChemicalEntity](ChemicalEntity.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
