
# Slot: genes




URI: [bp:biologicalProcess__genes](http://w3id.org/ontogpt/biological-process-templatebiologicalProcess__genes)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Gene](Gene.md)

## Parents


## Children


## Used by

 * [BiologicalProcess](BiologicalProcess.md)
