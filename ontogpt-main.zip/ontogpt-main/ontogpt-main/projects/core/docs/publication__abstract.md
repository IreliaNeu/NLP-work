
# Slot: abstract


The abstract of the publication

URI: [core:publication__abstract](http://w3id.org/ontogpt/core/publication__abstract)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Publication](Publication.md)
