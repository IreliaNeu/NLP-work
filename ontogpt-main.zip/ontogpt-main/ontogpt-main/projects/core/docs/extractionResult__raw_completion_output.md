
# Slot: raw_completion_output




URI: [core:extractionResult__raw_completion_output](http://w3id.org/ontogpt/core/extractionResult__raw_completion_output)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ExtractionResult](ExtractionResult.md)
