
# Slot: qualifier


A qualifier for the statements, e.g. "NOT" for negation

URI: [core:triple__qualifier](http://w3id.org/ontogpt/core/triple__qualifier)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
