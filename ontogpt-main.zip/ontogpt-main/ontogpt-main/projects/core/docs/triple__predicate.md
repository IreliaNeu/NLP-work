
# Slot: predicate




URI: [core:triple__predicate](http://w3id.org/ontogpt/core/triple__predicate)


## Domain and Range

None &#8594;  <sub>0..1</sub> [RelationshipType](RelationshipType.md)

## Parents


## Children


## Used by

 * [Triple](Triple.md)
