
# Slot: background_count


The background count

URI: [ontoenrich:classEnrichmentResult__background_count](https://w3id.org/oak/class-enrichment/classEnrichmentResult__background_count)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
