
# Slot: class_label


The class label

URI: [ontoenrich:classEnrichmentResult__class_label](https://w3id.org/oak/class-enrichment/classEnrichmentResult__class_label)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
