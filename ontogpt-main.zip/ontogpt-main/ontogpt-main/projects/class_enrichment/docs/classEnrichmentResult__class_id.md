
# Slot: class_id


The class id

URI: [ontoenrich:classEnrichmentResult__class_id](https://w3id.org/oak/class-enrichment/classEnrichmentResult__class_id)


## Domain and Range

None &#8594;  <sub>1..1</sub> [Uriorcurie](types/Uriorcurie.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
