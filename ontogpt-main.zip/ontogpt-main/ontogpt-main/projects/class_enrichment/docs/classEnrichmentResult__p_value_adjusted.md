
# Slot: p_value_adjusted


The adjusted p-value

URI: [ontoenrich:classEnrichmentResult__p_value_adjusted](https://w3id.org/oak/class-enrichment/classEnrichmentResult__p_value_adjusted)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Float](types/Float.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
