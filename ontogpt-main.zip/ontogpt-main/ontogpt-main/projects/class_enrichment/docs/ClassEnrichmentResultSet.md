
# Class: ClassEnrichmentResultSet


A collection of enrichemt results

URI: [ontoenrich:ClassEnrichmentResultSet](https://w3id.org/oak/class-enrichment/ClassEnrichmentResultSet)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[ClassEnrichmentResult]<results%200..*-++[ClassEnrichmentResultSet],[ClassEnrichmentResult])](https://yuml.me/diagram/nofunky;dir:TB/class/[ClassEnrichmentResult]<results%200..*-++[ClassEnrichmentResultSet],[ClassEnrichmentResult])

## Attributes


### Own

 * [➞results](classEnrichmentResultSet__results.md)  <sub>0..\*</sub>
     * Description: The enrichment results
     * Range: [ClassEnrichmentResult](ClassEnrichmentResult.md)
