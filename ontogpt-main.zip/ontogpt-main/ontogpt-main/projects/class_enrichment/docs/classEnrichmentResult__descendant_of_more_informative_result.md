
# Slot: descendant_of_more_informative_result


This term is more specific than a previously reported result

URI: [ontoenrich:classEnrichmentResult__descendant_of_more_informative_result](https://w3id.org/oak/class-enrichment/classEnrichmentResult__descendant_of_more_informative_result)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Boolean](types/Boolean.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
