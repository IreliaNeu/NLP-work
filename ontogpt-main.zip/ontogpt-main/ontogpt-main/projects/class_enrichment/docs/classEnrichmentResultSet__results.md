
# Slot: results


The enrichment results

URI: [ontoenrich:classEnrichmentResultSet__results](https://w3id.org/oak/class-enrichment/classEnrichmentResultSet__results)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ClassEnrichmentResult](ClassEnrichmentResult.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResultSet](ClassEnrichmentResultSet.md)
