
# Slot: probability


The probability, as estimated by model-based approaches

URI: [ontoenrich:classEnrichmentResult__probability](https://w3id.org/oak/class-enrichment/classEnrichmentResult__probability)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Float](types/Float.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
