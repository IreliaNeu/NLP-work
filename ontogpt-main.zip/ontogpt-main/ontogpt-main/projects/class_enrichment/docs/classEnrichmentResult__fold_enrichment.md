
# Slot: fold_enrichment


The fold enrichment

URI: [ontoenrich:classEnrichmentResult__fold_enrichment](https://w3id.org/oak/class-enrichment/classEnrichmentResult__fold_enrichment)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Float](types/Float.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
