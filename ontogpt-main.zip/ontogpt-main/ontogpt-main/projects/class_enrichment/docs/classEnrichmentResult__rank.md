
# Slot: rank


The rank of this result

URI: [ontoenrich:classEnrichmentResult__rank](https://w3id.org/oak/class-enrichment/classEnrichmentResult__rank)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
