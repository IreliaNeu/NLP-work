
# Type: Position




URI: [ontoenrich:Position](https://w3id.org/oak/class-enrichment/Position)

|  |  |  |
| --- | --- | --- |
| Parent type | | [Integer](types/Integer.md) |
| Root (builtin) type | | **int** |
