
# Slot: sample_total


The total number of entities in the sample

URI: [ontoenrich:classEnrichmentResult__sample_total](https://w3id.org/oak/class-enrichment/classEnrichmentResult__sample_total)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
