
# Slot: p_value_cutoff


p-value cutoff for enrichment

URI: [ontoenrich:classEnrichmentConfiguration__p_value_cutoff](https://w3id.org/oak/class-enrichment/classEnrichmentConfiguration__p_value_cutoff)


## Domain and Range

None &#8594;  <sub>1..1</sub> [Float](types/Float.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentConfiguration](ClassEnrichmentConfiguration.md)
