
# Slot: sample_count


The number of entities in the sample with this class

URI: [ontoenrich:classEnrichmentResult__sample_count](https://w3id.org/oak/class-enrichment/classEnrichmentResult__sample_count)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)
