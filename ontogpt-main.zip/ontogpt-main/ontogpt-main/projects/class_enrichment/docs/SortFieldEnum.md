
# Enum: SortFieldEnum


The field to sort by

URI: [ontoenrich:SortFieldEnum](https://w3id.org/oak/class-enrichment/SortFieldEnum)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
| ANY |  |  |  |
| P_VALUE |  |  |  |

