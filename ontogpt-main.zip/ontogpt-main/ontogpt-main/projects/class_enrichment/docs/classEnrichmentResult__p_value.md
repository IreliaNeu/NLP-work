
# Slot: p_value


The p-value

URI: [ontoenrich:classEnrichmentResult__p_value](https://w3id.org/oak/class-enrichment/classEnrichmentResult__p_value)


## Domain and Range

None &#8594;  <sub>1..1</sub> [Float](types/Float.md)

## Parents


## Children


## Used by

 * [ClassEnrichmentResult](ClassEnrichmentResult.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | OBI:0000175 |

